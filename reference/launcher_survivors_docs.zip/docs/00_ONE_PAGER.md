# Launcher Survivors

## Pitch
A launcher game where each run begins with a skill-based launch. During flight and rolling, enemies swarm and slow you while auto-weapons fire survivor-style. Distance + kills fuel your score. Fast runs, big builds, satisfying chaos.

## Design Pillars
- Tactile launch
- Momentum-based combat
- Build escalation
- Short session runs (2–6 minutes)
