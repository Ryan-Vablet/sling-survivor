# Art & Audio

Recommended Pack:
Kenney Space Shooter Redux (CC0)

Place spritesheet in src/assets.

Audio: Placeholder SFX acceptable for prototype.
