# Balance Tuning (Phase 1)

- Enemy spawn increases with distance
- Contact slows player meaningfully
- Weapon DPS allows survival but not trivial clearing
