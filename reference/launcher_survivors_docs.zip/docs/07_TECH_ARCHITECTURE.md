# Tech Architecture

Stack:
- Vite
- TypeScript
- PixiJS

Structure:

src/
  app/
  core/
  render/
  sim/
  content/
  ui/
  assets/

Fixed timestep game loop recommended (60hz).
