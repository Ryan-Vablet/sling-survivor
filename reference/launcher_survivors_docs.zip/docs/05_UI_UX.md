# UI / UX

HUD:
- Distance (meters)
- Speed
- Kills
- HP bar

Flow:
Title Screen -> Run -> End Screen -> Restart
