# Phases & Scope

## Phase 1 (MVP)
- Launch mechanic
- Simple terrain
- Two enemy types
- One auto-weapon
- HUD
- End screen

## Later Phases
- Weapon evolutions
- Biomes
- Meta progression
- Bosses
