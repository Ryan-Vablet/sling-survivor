# Layout Mockups

HUD Layout:

Distance: 1234m   Speed: 45 m/s   Kills: 12        HP ██████

[ Gameplay Area ]
