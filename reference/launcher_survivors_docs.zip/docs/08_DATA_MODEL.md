# Data Models (TypeScript)

type PlayerStats = {
  hpMax: number;
  damage: number;
  fireRate: number;
  dragCoeff: number;
  groundFriction: number;
};

type EnemyDef = {
  id: string;
  hp: number;
  speed: number;
  contactDrag: number;
};

type WeaponDef = {
  id: string;
  cooldown: number;
  damage: number;
  projSpeed: number;
};
