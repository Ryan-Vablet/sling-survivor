# Gameplay Systems

## Player Stats
- hp
- mass
- dragCoeff
- groundFriction
- weaponCooldown
- weaponDamage

## Enemies
- Chaser: applies drag + damage
- Blocker: knockback + damage

## Weapon
- Auto-cannon
- Fires at nearest enemy in range
