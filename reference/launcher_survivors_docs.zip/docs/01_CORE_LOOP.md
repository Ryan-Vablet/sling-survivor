# Core Loop

1. Launch (aim + power)
2. Flight / Roll (physics movement + terrain)
3. Combat (auto-fire + enemies + pickups later)
4. Cashout (distance, kills, score)
5. Repeat

Score Formula:
RunScore = DistanceMeters * (1 + KillScore / 1000)
