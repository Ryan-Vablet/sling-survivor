# Controls & Feel

Mouse drag:
- Direction = angle
- Drag distance = power
- Release = fire

Optional mid-air tilt (future):
- A/D keys

Feel Targets:
- Arcade gravity
- Medium ground friction
- Small default bounce
