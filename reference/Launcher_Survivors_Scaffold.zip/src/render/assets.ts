/**
 * Asset loader placeholder.
 * Drop Kenney sprites into src/assets and load them here when ready.
 *
 * For Phase 1 scaffold we render simple Graphics shapes so the project runs without assets.
 */
export async function loadAssets() {
  // no-op for now
}
